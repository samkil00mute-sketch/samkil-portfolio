import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CNRGJDz2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var site = {
	name: "Samuel Kilonzo Mutemi",
	shortName: "SAMKIL",
	monogram: "SK",
	title: "Frontend developer & graphic designer",
	tagline: "Websites, posters, and digital work for real local needs.",
	location: "Mwingi, Kitui County, Kenya",
	phone: "0742231190",
	phoneHref: "tel:+254742231190",
	phoneDisplay: "+254 742 231 190",
	email: "samkil00mute@gmail.com",
	availability: "Open to internships, freelance, and junior roles",
	education: {
		school: "Jaramogi Oginga Odinga University of Science and Technology",
		schoolShort: "JOOUST",
		degree: "Bachelor's Degree — Computer Security and Forensics",
		year: "Second Year"
	},
	profile: ["I am a second-year Computer Security and Forensics student who builds frontend websites and digital posters for local clients, with AI tools in the workflow when they make the work sharper.", "I am looking for professional experience — internships, freelance, or a team — where I can contribute practical web and design skills and keep growing as a technology professional."],
	languages: [
		{
			name: "English",
			level: "Good"
		},
		{
			name: "Swahili",
			level: "Good"
		},
		{
			name: "Kikamba",
			level: "Native"
		}
	],
	attributes: [
		"Creative and innovative",
		"Willing to learn",
		"Technology-oriented",
		"Self-motivated",
		"Problem-solving mindset",
		"Attention to visual detail",
		"Adaptable",
		"Independent and collaborative"
	]
};
var nav = [
	{
		href: "#work",
		label: "Work"
	},
	{
		href: "#about",
		label: "About"
	},
	{
		href: "#skills",
		label: "Skills"
	},
	{
		href: "#contact",
		label: "Contact"
	}
];
var skillGroups = [
	{
		id: "frontend",
		label: "Frontend",
		items: [
			"HTML, CSS and JavaScript",
			"Website design and development",
			"Usable, visual interfaces"
		]
	},
	{
		id: "design",
		label: "Graphic design",
		items: [
			"Digital poster design",
			"Promotional graphics",
			"Creative content development"
		]
	},
	{
		id: "ai",
		label: "AI practice",
		items: [
			"AI prompt engineering",
			"Generative AI",
			"AI-assisted design and web work"
		]
	},
	{
		id: "security",
		label: "Security studies",
		items: [
			"Computer security concepts",
			"Computer forensics concepts",
			"Digital research"
		]
	}
];
var experience = {
	role: "Web Developer & Graphic Designer",
	org: "Freelance / local digital projects",
	points: [
		"Designed and developed websites for local clients, with a focus on clear structure and attractive presentation.",
		"Created digital posters and promotional graphics for local businesses and individuals.",
		"Used AI tools to assist creative design, content development, and digital production.",
		"Delivered customized solutions based on each client's requirements."
	]
};
var projects = [{
	id: "safaris",
	kicker: "Web concept",
	title: "SAMKIL Safaris",
	summary: "A bus booking website concept covering passenger booking, seat selection, routes, fares, booking information, and an admin side.",
	image: "/images/project-safaris.jpg",
	alt: "A Kenyan coach bus on an empty highway through dry savanna at dusk",
	tags: [
		"Booking",
		"Seat maps",
		"Routes & fares",
		"Admin"
	]
}, {
	id: "academy",
	kicker: "Web concept",
	title: "SAMKIL Academy",
	summary: "A school website concept built to present information in a simple, attractive, and user-friendly format.",
	image: "/images/project-academy.jpg",
	alt: "A quiet Kenyan school courtyard in morning light",
	tags: [
		"Information architecture",
		"School site",
		"Clear layout"
	]
}];
var posters = [
	{
		id: "weave",
		title: "Kiondo weave study",
		caption: "Texture-led poster work from sisal and dyed fiber — pattern as the whole message.",
		image: "/images/poster-weave.jpg",
		alt: "Close-up of woven sisal fibers in cream, charcoal, and burnt sienna"
	},
	{
		id: "stamp",
		title: "Eastern Kenya mark",
		caption: "Screenprint-style composition with a circular stamp and contour lines.",
		image: "/images/poster-stamp.jpg",
		alt: "Abstract ink and screenprint composition in charcoal, cream, and sienna"
	},
	{
		id: "desk",
		title: "Studio still",
		caption: "Cut paper, ink, and earth-tone swatches — the working table behind the posters.",
		image: "/images/poster-desk.jpg",
		alt: "Graphic design desk still life with paper, ruler, ink, and color swatches"
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sienna/70 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-paper text-ink hover:bg-paper-dim",
			sienna: "bg-sienna text-paper hover:bg-sienna-deep",
			outline: "border border-line-strong bg-transparent text-paper hover:bg-paper/8",
			ghost: "text-paper hover:bg-paper/8",
			ink: "bg-ink text-paper hover:bg-ink-soft",
			"outline-ink": "border border-line-ink bg-transparent text-ink hover:bg-ink/6"
		},
		size: {
			default: "h-11 px-5 text-sm rounded-full",
			sm: "h-9 px-4 text-sm rounded-full",
			lg: "h-12 px-6 text-base rounded-full",
			icon: "size-11 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
export { posters as a, skillGroups as c, nav as i, cn as n, projects as o, experience as r, site as s, Button as t };
