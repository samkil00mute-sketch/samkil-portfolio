//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-O02H1Af-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/cv"],
		preloads: ["/assets/index-Dy5XtmUX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dy5XtmUX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BC7Ug-Fb.js", "/assets/button-Blp8GXYy.js"]
	},
	"/cv": {
		filePath: "/workspace/src/routes/cv.tsx",
		children: void 0,
		preloads: ["/assets/cv-BiTPK6Fd.js", "/assets/button-Blp8GXYy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
