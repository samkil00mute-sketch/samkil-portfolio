import { site } from "@/data/site";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/section-heading";

export function About() {
  return (
    <section id="about" className="bg-paper text-ink">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-12 lg:gap-16 lg:py-28">
        <div className="lg:col-span-5">
          <div className="overflow-hidden rounded-xl">
            <img
              src="/images/identity-mark.jpg"
              alt="Minimal acacia silhouette against a cream sky — SAMKIL mark"
              className="aspect-square w-full object-cover"
              width={1408}
              height={1408}
              loading="lazy"
            />
          </div>
        </div>

        <div className="lg:col-span-7">
          <SectionHeading index="01" title="About" tone="ink" />
          <div className="mt-8 space-y-5 text-base leading-relaxed text-stone-deep">
            {site.profile.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>

          <div className="mt-10 grid gap-8 sm:grid-cols-2">
            <div>
              <h3 className="text-xs tracking-widest text-stone-deep uppercase">
                Education
              </h3>
              <p className="mt-2 font-display text-xl leading-snug text-ink">
                {site.education.school}
              </p>
              <p className="mt-2 text-sm text-stone-deep">
                {site.education.degree}
                <span className="block">{site.education.year}</span>
              </p>
            </div>
            <div>
              <h3 className="text-xs tracking-widest text-stone-deep uppercase">
                Languages
              </h3>
              <ul className="mt-2 space-y-1.5 text-sm text-ink">
                {site.languages.map((lang) => (
                  <li key={lang.name} className="flex justify-between gap-4">
                    <span>{lang.name}</span>
                    <span className="text-stone-deep">{lang.level}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-2">
            {site.attributes.map((item) => (
              <Badge key={item} variant="paper">
                {item}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
