import { type FormEvent, useState } from "react";
import { Check, Copy, Mail, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";
import { site } from "@/data/site";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SectionHeading } from "@/components/section-heading";

export function Contact() {
  const [copied, setCopied] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(site.email);
      setCopied(true);
      toast.success("Email copied");
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("Could not copy. Use the address below.");
    }
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const subject = encodeURIComponent(`Hello Samuel — ${name || "portfolio"}`);
    const body = encodeURIComponent(
      `${message}\n\n— ${name}\n${email}`,
    );
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
  }

  return (
    <section id="contact" className="bg-paper text-ink">
      <div className="mx-auto grid max-w-6xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-12 lg:py-28">
        <div className="lg:col-span-5">
          <SectionHeading index="04" title="Let’s work" kicker="Contact" tone="ink" />
          <p className="mt-5 max-w-sm text-base leading-relaxed text-stone-deep">
            {site.availability}. Send a note about a site, a poster, or an
            internship — I reply to email.
          </p>

          <ul className="mt-10 space-y-5">
            <li className="flex items-start gap-3">
              <Mail className="mt-0.5 size-4 text-sienna-deep" aria-hidden="true" />
              <div>
                <p className="text-xs tracking-widest text-stone-deep uppercase">
                  Email
                </p>
                <a
                  href={`mailto:${site.email}`}
                  className="mt-1 block text-sm text-ink underline-offset-4 hover:underline"
                >
                  {site.email}
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Phone className="mt-0.5 size-4 text-sienna-deep" aria-hidden="true" />
              <div>
                <p className="text-xs tracking-widest text-stone-deep uppercase">
                  Phone
                </p>
                <a
                  href={site.phoneHref}
                  className="mt-1 block text-sm text-ink underline-offset-4 hover:underline"
                >
                  {site.phoneDisplay}
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <MapPin className="mt-0.5 size-4 text-sienna-deep" aria-hidden="true" />
              <div>
                <p className="text-xs tracking-widest text-stone-deep uppercase">
                  Location
                </p>
                <p className="mt-1 text-sm text-ink">{site.location}</p>
              </div>
            </li>
          </ul>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button type="button" variant="ink" onClick={copyEmail}>
              {copied ? <Check /> : <Copy />}
              {copied ? "Copied" : "Copy email"}
            </Button>
            <Button asChild variant="outline-ink">
              <a href="/cv">View CV</a>
            </Button>
          </div>
        </div>

        <form
          onSubmit={onSubmit}
          className="rounded-xl bg-ink p-6 text-paper sm:p-8 lg:col-span-7"
        >
          <p className="font-display text-xl font-medium">Send a message</p>
          <p className="mt-1 text-sm text-stone">
            Opens your email app with the note filled in.
          </p>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                name="name"
                autoComplete="name"
                required
                value={name}
                onChange={(event) => setName(event.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Your email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>
          </div>
          <div className="mt-5 grid gap-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              name="message"
              required
              rows={6}
              value={message}
              onChange={(event) => setMessage(event.target.value)}
            />
          </div>
          <Button type="submit" className="mt-6" size="lg">
            Compose email
          </Button>
        </form>
      </div>
    </section>
  );
}
