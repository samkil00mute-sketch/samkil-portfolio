import { ArrowDownRight, MapPin } from "lucide-react";
import { site } from "@/data/site";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section
      id="top"
      className="relative isolate min-h-dvh overflow-hidden bg-ink"
    >
      <div className="absolute inset-0">
        <img
          src="/images/hero-landscape.jpg"
          alt="Dry savanna and acacia trees near Mwingi, Kitui County, at late afternoon"
          className="size-full object-cover"
          width={1792}
          height={1008}
        />
        <div className="absolute inset-0 bg-linear-to-t from-ink via-ink/65 to-ink/45" />
        <div className="absolute inset-x-0 top-0 h-40 bg-linear-to-b from-ink/80 to-transparent" />
      </div>

      <div className="relative mx-auto flex min-h-dvh max-w-6xl flex-col justify-end px-4 pt-24 pb-10 sm:px-6 sm:pb-14">
        <div className="flex flex-col gap-8">
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs tracking-widest text-stone uppercase">
            <p className="stagger-in flex items-center gap-1.5">
              <MapPin className="size-3.5 text-sienna" aria-hidden="true" />
              {site.location}
            </p>
            <p className="stagger-in">Portfolio / 2026</p>
          </div>

          <div className="max-w-3xl">
            <p className="stagger-in mb-4 text-sm tracking-wide text-sienna">
              {site.title}
            </p>
            <h1 className="stagger-in font-display text-5xl leading-none font-medium tracking-tight text-paper sm:text-6xl lg:text-7xl">
              Samuel
              <span className="block italic">Kilonzo Mutemi</span>
            </h1>
            <p className="stagger-in mt-6 max-w-md text-base leading-relaxed text-stone sm:text-lg">
              {site.tagline} Computer Security and Forensics student at {site.education.schoolShort}.
            </p>
          </div>

          <div className="stagger-in flex flex-wrap items-center gap-3">
            <Button asChild size="lg">
              <a href="#work">
                View work
                <ArrowDownRight className="size-4" />
              </a>
            </Button>
            <Button asChild variant="outline" size="lg">
              <a href="#contact">Get in touch</a>
            </Button>
          </div>

          <dl className="stagger-in grid grid-cols-2 gap-4 border-t border-line pt-6 sm:grid-cols-3">
            <div>
              <dt className="text-xs tracking-widest text-stone uppercase">
                Studies
              </dt>
              <dd className="mt-1 text-sm text-paper">
                {site.education.degree.split(" — ")[1]}
              </dd>
            </div>
            <div>
              <dt className="text-xs tracking-widest text-stone uppercase">
                Year
              </dt>
              <dd className="mt-1 text-sm text-paper">{site.education.year}</dd>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <dt className="text-xs tracking-widest text-stone uppercase">
                Status
              </dt>
              <dd className="mt-1 text-sm text-paper">{site.availability}</dd>
            </div>
          </dl>
        </div>
      </div>
    </section>
  );
}
