import { cn } from "@/lib/utils";

export function SectionHeading({
  index,
  title,
  kicker,
  tone = "paper",
}: {
  index: string;
  title: string;
  kicker?: string;
  tone?: "paper" | "ink";
}) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div>
        <p
          className={cn(
            "text-xs tracking-widest uppercase",
            tone === "paper" ? "text-sienna" : "text-sienna-deep",
          )}
        >
          {index} — {kicker ?? title}
        </p>
        <h2
          className={cn(
            "mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl",
            tone === "paper" ? "text-paper" : "text-ink",
          )}
        >
          {title}
        </h2>
      </div>
    </div>
  );
}
