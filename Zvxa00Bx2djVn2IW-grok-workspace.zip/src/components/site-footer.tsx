import { site } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-ink">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <p className="text-sm text-stone">
          {site.shortName} · {site.name}
        </p>
        <p className="text-sm text-stone">
          References available upon request.
        </p>
      </div>
    </footer>
  );
}
