import { experience, skillGroups } from "@/data/site";
import { SectionHeading } from "@/components/section-heading";

export function Skills() {
  return (
    <section id="skills" className="bg-ink-soft">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28">
        <SectionHeading index="03" title="Skills" kicker="Capabilities" />

        <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2">
          {skillGroups.map((group) => (
            <article key={group.id} className="bg-ink-soft p-6 sm:p-8">
              <h3 className="font-display text-xl font-medium text-paper">
                {group.label}
              </h3>
              <ul className="mt-5 space-y-3">
                {group.items.map((item) => (
                  <li
                    key={item}
                    className="border-b border-line pb-3 text-sm text-stone last:border-0 last:pb-0"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>

        <article className="mt-16 border-t border-line pt-12">
          <p className="text-xs tracking-widest text-sienna uppercase">
            Practical experience
          </p>
          <h3 className="mt-3 font-display text-2xl font-medium text-paper">
            {experience.role}
          </h3>
          <p className="mt-1 text-sm text-stone">{experience.org}</p>
          <ul className="mt-8 grid gap-4 md:grid-cols-2">
            {experience.points.map((point) => (
              <li
                key={point}
                className="rounded-lg border border-line bg-ink p-5 text-sm leading-relaxed text-stone"
              >
                {point}
              </li>
            ))}
          </ul>
        </article>
      </div>
    </section>
  );
}
