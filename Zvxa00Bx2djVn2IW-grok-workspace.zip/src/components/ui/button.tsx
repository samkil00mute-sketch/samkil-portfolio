import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sienna/70 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.96]",
  {
    variants: {
      variant: {
        default: "bg-paper text-ink hover:bg-paper-dim",
        sienna: "bg-sienna text-paper hover:bg-sienna-deep",
        outline:
          "border border-line-strong bg-transparent text-paper hover:bg-paper/8",
        ghost: "text-paper hover:bg-paper/8",
        ink: "bg-ink text-paper hover:bg-ink-soft",
        "outline-ink":
          "border border-line-ink bg-transparent text-ink hover:bg-ink/6",
      },
      size: {
        default: "h-11 px-5 text-sm rounded-full",
        sm: "h-9 px-4 text-sm rounded-full",
        lg: "h-12 px-6 text-base rounded-full",
        icon: "size-11 rounded-full",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
