import * as React from "react";
import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        suppressHydrationWarning
        className={cn(
          "flex h-11 w-full rounded-md border border-line bg-ink-soft px-3 text-sm text-paper placeholder:text-stone outline-none transition-[border-color,box-shadow] duration-150 focus-visible:border-sienna focus-visible:ring-2 focus-visible:ring-sienna/30 disabled:cursor-not-allowed disabled:opacity-50",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Input.displayName = "Input";

export { Input };
