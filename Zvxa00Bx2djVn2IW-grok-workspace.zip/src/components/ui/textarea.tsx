import * as React from "react";
import { cn } from "@/lib/utils";

const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<"textarea">
>(({ className, ...props }, ref) => {
  return (
    <textarea
      suppressHydrationWarning
      className={cn(
        "flex min-h-32 w-full rounded-lg border border-line bg-ink-soft px-3 py-3 text-sm text-paper placeholder:text-stone outline-none transition-[border-color,box-shadow] duration-150 focus-visible:border-sienna focus-visible:ring-2 focus-visible:ring-sienna/30 disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      ref={ref}
      {...props}
    />
  );
});
Textarea.displayName = "Textarea";

export { Textarea };
