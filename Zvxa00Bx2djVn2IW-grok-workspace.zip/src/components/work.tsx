import { useState } from "react";
import { posters, projects } from "@/data/site";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SectionHeading } from "@/components/section-heading";
import { cn } from "@/lib/utils";

export function Work() {
  const [openId, setOpenId] = useState<string | null>(null);
  const selected = posters.find((poster) => poster.id === openId) ?? null;

  return (
    <section id="work" className="bg-ink">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28">
        <SectionHeading index="02" title="Selected work" kicker="Projects" />
        <p className="mt-4 max-w-xl text-base leading-relaxed text-stone">
          Website concepts and poster work made for local clients and personal
          practice — frontend first, with graphic design in the same toolkit.
        </p>

        <div className="mt-14 space-y-20">
          {projects.map((project, index) => (
            <article
              key={project.id}
              className="grid items-stretch gap-8 lg:grid-cols-12 lg:gap-12"
            >
              <div
                className={cn(
                  "overflow-hidden rounded-xl lg:col-span-7",
                  index % 2 === 1 && "lg:order-2",
                )}
              >
                <img
                  src={project.image}
                  alt={project.alt}
                  className="aspect-landscape h-full w-full object-cover transition-transform duration-500 ease-out hover:scale-105"
                  width={1792}
                  height={1008}
                  loading="lazy"
                />
              </div>
              <div
                className={cn(
                  "flex flex-col justify-center lg:col-span-5",
                  index % 2 === 1 && "lg:order-1",
                )}
              >
                <p className="text-xs tracking-widest text-sienna uppercase">
                  {project.kicker}
                </p>
                <h3 className="mt-3 font-display text-3xl font-medium tracking-tight text-paper">
                  {project.title}
                </h3>
                <p className="mt-4 text-base leading-relaxed text-stone">
                  {project.summary}
                </p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <Badge key={tag}>{tag}</Badge>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-24">
          <h3 className="font-display text-2xl font-medium tracking-tight text-paper">
            Digital posters
          </h3>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-stone">
            Promotional graphics for local businesses and individuals, combining
            design principles with AI-assisted creative workflows. Open a piece
            to view it larger.
          </p>
          <ul className="mt-8 grid gap-4 sm:grid-cols-3">
            {posters.map((poster) => (
              <li key={poster.id}>
                <button
                  type="button"
                  onClick={() => setOpenId(poster.id)}
                  className="group w-full overflow-hidden rounded-xl text-left"
                >
                  <img
                    src={poster.image}
                    alt={poster.alt}
                    className="aspect-poster w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                    width={1200}
                    height={1600}
                    loading="lazy"
                  />
                  <span className="mt-3 block font-medium text-paper">
                    {poster.title}
                  </span>
                  <span className="mt-1 block text-sm text-stone">
                    {poster.caption}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <Dialog
        open={Boolean(selected)}
        onOpenChange={(open) => {
          if (!open) setOpenId(null);
        }}
      >
        {selected ? (
          <DialogContent className="p-3 sm:p-4">
            <img
              src={selected.image}
              alt={selected.alt}
              className="max-h-96 w-full rounded-lg object-contain"
            />
            <DialogHeader>
              <DialogTitle>{selected.title}</DialogTitle>
              <DialogDescription>{selected.caption}</DialogDescription>
            </DialogHeader>
          </DialogContent>
        ) : null}
      </Dialog>
    </section>
  );
}
