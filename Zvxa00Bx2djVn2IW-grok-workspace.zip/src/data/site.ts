export const site = {
  name: "Samuel Kilonzo Mutemi",
  shortName: "SAMKIL",
  monogram: "SK",
  title: "Frontend developer & graphic designer",
  tagline: "Websites, posters, and digital work for real local needs.",
  location: "Mwingi, Kitui County, Kenya",
  phone: "0742231190",
  phoneHref: "tel:+254742231190",
  phoneDisplay: "+254 742 231 190",
  email: "samkil00mute@gmail.com",
  availability: "Open to internships, freelance, and junior roles",
  education: {
    school: "Jaramogi Oginga Odinga University of Science and Technology",
    schoolShort: "JOOUST",
    degree: "Bachelor's Degree — Computer Security and Forensics",
    year: "Second Year",
  },
  profile: [
    "I am a second-year Computer Security and Forensics student who builds frontend websites and digital posters for local clients, with AI tools in the workflow when they make the work sharper.",
    "I am looking for professional experience — internships, freelance, or a team — where I can contribute practical web and design skills and keep growing as a technology professional.",
  ],
  languages: [
    { name: "English", level: "Good" },
    { name: "Swahili", level: "Good" },
    { name: "Kikamba", level: "Native" },
  ],
  attributes: [
    "Creative and innovative",
    "Willing to learn",
    "Technology-oriented",
    "Self-motivated",
    "Problem-solving mindset",
    "Attention to visual detail",
    "Adaptable",
    "Independent and collaborative",
  ],
} as const;

export const nav = [
  { href: "#work", label: "Work" },
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#contact", label: "Contact" },
] as const;

export const skillGroups = [
  {
    id: "frontend",
    label: "Frontend",
    items: [
      "HTML, CSS and JavaScript",
      "Website design and development",
      "Usable, visual interfaces",
    ],
  },
  {
    id: "design",
    label: "Graphic design",
    items: [
      "Digital poster design",
      "Promotional graphics",
      "Creative content development",
    ],
  },
  {
    id: "ai",
    label: "AI practice",
    items: [
      "AI prompt engineering",
      "Generative AI",
      "AI-assisted design and web work",
    ],
  },
  {
    id: "security",
    label: "Security studies",
    items: [
      "Computer security concepts",
      "Computer forensics concepts",
      "Digital research",
    ],
  },
] as const;

export const experience = {
  role: "Web Developer & Graphic Designer",
  org: "Freelance / local digital projects",
  points: [
    "Designed and developed websites for local clients, with a focus on clear structure and attractive presentation.",
    "Created digital posters and promotional graphics for local businesses and individuals.",
    "Used AI tools to assist creative design, content development, and digital production.",
    "Delivered customized solutions based on each client's requirements.",
  ],
} as const;

export const projects = [
  {
    id: "safaris",
    kicker: "Web concept",
    title: "SAMKIL Safaris",
    summary:
      "A bus booking website concept covering passenger booking, seat selection, routes, fares, booking information, and an admin side.",
    image: "/images/project-safaris.jpg",
    alt: "A Kenyan coach bus on an empty highway through dry savanna at dusk",
    tags: ["Booking", "Seat maps", "Routes & fares", "Admin"],
  },
  {
    id: "academy",
    kicker: "Web concept",
    title: "SAMKIL Academy",
    summary:
      "A school website concept built to present information in a simple, attractive, and user-friendly format.",
    image: "/images/project-academy.jpg",
    alt: "A quiet Kenyan school courtyard in morning light",
    tags: ["Information architecture", "School site", "Clear layout"],
  },
] as const;

export const posters = [
  {
    id: "weave",
    title: "Kiondo weave study",
    caption:
      "Texture-led poster work from sisal and dyed fiber — pattern as the whole message.",
    image: "/images/poster-weave.jpg",
    alt: "Close-up of woven sisal fibers in cream, charcoal, and burnt sienna",
  },
  {
    id: "stamp",
    title: "Eastern Kenya mark",
    caption:
      "Screenprint-style composition with a circular stamp and contour lines.",
    image: "/images/poster-stamp.jpg",
    alt: "Abstract ink and screenprint composition in charcoal, cream, and sienna",
  },
  {
    id: "desk",
    title: "Studio still",
    caption:
      "Cut paper, ink, and earth-tone swatches — the working table behind the posters.",
    image: "/images/poster-desk.jpg",
    alt: "Graphic design desk still life with paper, ruler, ink, and color swatches",
  },
] as const;
