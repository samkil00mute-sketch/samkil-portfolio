import { createFileRoute, Link } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import {
  experience,
  posters,
  projects,
  site,
  skillGroups,
} from "@/data/site";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/cv")({ component: CurriculumVitae });

function CurriculumVitae() {
  return (
    <div className="min-h-dvh bg-paper text-ink">
      <div className="no-print mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-5 sm:px-6">
        <Button asChild variant="outline-ink" size="sm">
          <Link to="/">Back to portfolio</Link>
        </Button>
        <Button
          type="button"
          variant="ink"
          size="sm"
          onClick={() => window.print()}
        >
          <Printer />
          Print / save PDF
        </Button>
      </div>

      <article className="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-10">
        <header className="border-b border-line-ink pb-6">
          <p className="text-xs tracking-widest text-sienna-deep uppercase">
            Curriculum Vitae
          </p>
          <h1 className="mt-2 font-display text-4xl font-medium tracking-tight">
            {site.name}
          </h1>
          <p className="mt-2 text-sm text-stone-deep">{site.title}</p>
          <p className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-ink">
            <a href={site.phoneHref}>{site.phoneDisplay}</a>
            <a href={`mailto:${site.email}`}>{site.email}</a>
            <span>{site.location}</span>
          </p>
        </header>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">
            Professional profile
          </h2>
          {site.profile.map((paragraph) => (
            <p
              key={paragraph}
              className="mt-3 text-sm leading-relaxed text-stone-deep"
            >
              {paragraph}
            </p>
          ))}
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">Education</h2>
          <p className="mt-3 text-sm font-medium">{site.education.school}</p>
          <p className="text-sm text-stone-deep">{site.education.degree}</p>
          <p className="text-sm text-stone-deep">{site.education.year}</p>
          <p className="mt-3 text-sm text-stone-deep">
            Kenya Certificate of Secondary Education (KCSE)
          </p>
          <p className="text-sm text-stone-deep">
            Kenya Certificate of Primary Education (KCPE)
          </p>
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">
            Technical and professional skills
          </h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            {skillGroups.map((group) => (
              <div key={group.id}>
                <h3 className="text-sm font-medium">{group.label}</h3>
                <ul className="mt-1 list-disc pl-4 text-sm text-stone-deep">
                  {group.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">
            Practical experience
          </h2>
          <p className="mt-3 text-sm font-medium">{experience.role}</p>
          <p className="text-sm text-stone-deep">{experience.org}</p>
          <ul className="mt-2 list-disc pl-4 text-sm leading-relaxed text-stone-deep">
            {experience.points.map((point) => (
              <li key={point}>{point}</li>
            ))}
          </ul>
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">
            Selected projects
          </h2>
          {projects.map((project) => (
            <div key={project.id} className="mt-4">
              <h3 className="text-sm font-medium">{project.title}</h3>
              <p className="text-sm leading-relaxed text-stone-deep">
                {project.summary}
              </p>
            </div>
          ))}
          <div className="mt-4">
            <h3 className="text-sm font-medium">
              Digital poster and graphic design
            </h3>
            <p className="text-sm leading-relaxed text-stone-deep">
              {posters.map((poster) => poster.title).join(", ")} — promotional
              posters and digital graphics for local individuals and businesses.
            </p>
          </div>
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">Languages</h2>
          <ul className="mt-2 list-disc pl-4 text-sm text-stone-deep">
            {site.languages.map((lang) => (
              <li key={lang.name}>
                {lang.name} — {lang.level}
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-8">
          <h2 className="font-display text-xl font-medium">
            Personal attributes
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-stone-deep">
            {site.attributes.join(" · ")}
          </p>
        </section>

        <p className="mt-10 text-xs tracking-wide text-stone-deep uppercase">
          References available upon request
        </p>
      </article>
    </div>
  );
}
